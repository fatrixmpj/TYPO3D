<?php

return [
	'html' => [
		'checkout' => [
			'standard' => [
				'summary' => [
					'name' => 'Frey'
				],
			],
		],
	],
	'jsonapi' => [
	],
];
