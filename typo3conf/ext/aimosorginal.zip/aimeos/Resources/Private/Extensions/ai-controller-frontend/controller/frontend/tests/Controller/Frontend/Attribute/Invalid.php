<?php

namespace Aimeos\Controller\Frontend\Attribute;


class Invalid
{
}
