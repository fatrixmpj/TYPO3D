<?php

namespace Aimeos\Controller\Frontend\Stock;


class Invalid
{
}
