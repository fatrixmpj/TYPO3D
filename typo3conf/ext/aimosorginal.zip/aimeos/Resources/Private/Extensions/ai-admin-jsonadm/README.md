<a href="https://aimeos.org/">
    <img src="https://aimeos.org/fileadmin/template/icons/logo.png" alt="Aimeos logo" title="Aimeos" align="right" height="60" />
</a>

# Aimeos JSON API admin interface

[![Build Status](https://travis-ci.org/aimeos/ai-admin-jsonadm.png?branch=master)](https://travis-ci.org/aimeos/ai-admin-jsonadm)
[![Coverage Status](https://coveralls.io/repos/aimeos/ai-admin-jsonadm/badge.svg?branch=master)](https://coveralls.io/r/aimeos/ai-admin-jsonadm?branch=master)
[![Scrutinizer Code Quality](https://scrutinizer-ci.com/g/aimeos/ai-admin-jsonadm/badges/quality-score.png?b=master)](https://scrutinizer-ci.com/g/aimeos/ai-admin-jsonadm/?branch=master)
[![License](https://poser.pugx.org/aimeos/ai-admin-jsonadm/license.svg)](https://packagist.org/packages/aimeos/ai-admin-jsonadm)

JSON API based admin interface for Aimeos e-commerce projects

[![Aimeos demo](https://aimeos.org/fileadmin/user_upload/demo.jpg)](http://demo.aimeos.org/)
