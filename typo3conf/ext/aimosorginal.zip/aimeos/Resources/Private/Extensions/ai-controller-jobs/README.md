<a href="https://aimeos.org/">
    <img src="https://aimeos.org/fileadmin/template/icons/logo.png" alt="Aimeos logo" title="Aimeos" align="right" height="60" />
</a>

# Aimeos job controllers

[![Build Status](https://travis-ci.org/aimeos/ai-controller-jobs.png?branch=master)](https://travis-ci.org/aimeos/ai-controller-jobs)
[![Coverage Status](https://coveralls.io/repos/aimeos/ai-controller-jobs/badge.svg?branch=master)](https://coveralls.io/r/aimeos/ai-controller-jobs?branch=master)
[![Scrutinizer Code Quality](https://scrutinizer-ci.com/g/aimeos/ai-controller-jobs/badges/quality-score.png?b=master)](https://scrutinizer-ci.com/g/aimeos/ai-controller-jobs/?branch=master)
[![License](https://poser.pugx.org/aimeos/ai-controller-jobs/license.svg)](https://packagist.org/packages/aimeos/ai-controller-jobs)

Aimeos job controllers for scheduled tasks in e-commerce projects

[![Aimeos demo](https://aimeos.org/fileadmin/user_upload/demo.jpg)](http://demo.aimeos.org/)
