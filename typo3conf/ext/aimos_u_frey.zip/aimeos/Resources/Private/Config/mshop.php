<?php

return array(
	'index' => array(
		'manager' => array(
			'name' => 'MySQL',
			'attribute' => array(
				'name' => 'MySQL',
			),
			'catalog' => array(
				'name' => 'MySQL',
			),
			'price' => array(
				'name' => 'MySQL',
			),
			'text' => array(
				'name' => 'MySQL',
			),
		),
	),
	'customer' => array(
		'manager' => array(
			'name' => 'Typo3',
		)
	),
);
