<?php

return array(
	'jqadm' => array(
		'product' => array(
			'decorators' => array(
				'global' => null,
			),
		),
		'product/category' => array(
			'decorators' => array(
				'local' => null,
			),
		),
	),
);