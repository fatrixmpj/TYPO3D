<?php

namespace Aimeos\Controller\Frontend\Order;


class Invalid
{
}
