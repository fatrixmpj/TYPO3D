<?php

namespace Aimeos\Controller\Frontend\Catalog;


class Invalid
{
}
