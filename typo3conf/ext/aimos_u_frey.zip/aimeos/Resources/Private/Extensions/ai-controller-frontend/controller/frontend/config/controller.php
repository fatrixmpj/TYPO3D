<?php

return array(
	'frontend' => array(
		'basket' => array(
			'decorators' => array(
				'local' => array( 'Category', 'Bundle', 'Select' ),
			),
		),
	),
);
