<?php

namespace Aimeos\Controller\Frontend\Basket;


class Invalid
{
}
