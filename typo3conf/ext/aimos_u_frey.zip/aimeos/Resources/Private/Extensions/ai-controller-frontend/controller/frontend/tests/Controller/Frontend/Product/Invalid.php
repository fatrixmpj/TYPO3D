<?php

namespace Aimeos\Controller\Frontend\Product;


class Invalid
{
}
