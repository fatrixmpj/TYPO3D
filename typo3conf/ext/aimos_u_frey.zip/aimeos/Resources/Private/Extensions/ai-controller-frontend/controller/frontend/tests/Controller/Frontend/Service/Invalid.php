<?php

namespace Aimeos\Controller\Frontend\Service;


class Invalid
{
}
